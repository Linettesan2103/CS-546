//Here you will import route files and export the constructor method as shown in lecture code and worked in previous labs.
const userRoutes = require('./userRoutes');
const adminRoutes = require('./adminRoutes');

const constructorMethod = (app) => {
  app.use('/users', userRoutes);
  app.use('/admin', adminRoutes);

  app.use('*', (req, res) => {
    res.status(404).json({ error: 'Not found' });
  });
};

module.exports = constructorMethod;