import express from 'express';
import { registerUser, loginUser } from '../data/users.js';

const router = express.Router();

router.route('/').get(async (req, res) => {
  return res.json({error: 'YOU SHOULD NOT BE HERE!'});
});

router
  .route('/register')
  .get(async (req, res) => {
    res.render('register');
  })
  .post(async (req, res) => {
    const { firstName, lastName, emailAddress, password, role } = req.body;
    const result = await registerUser(firstName, lastName, emailAddress, password, role);
    req.session.user = result;
    res.status(200).send(result);
  });

router
  .route('/login')
  .get((req, res) => {
    res.render('login');
  })
  .post(async (req, res) => {
    const { emailAddress, password } = req.body;
      const user = await usersCollection.findOne({ emailAddress: emailAddress.toLowerCase() });
      if (!user) {
        return res.status(400).render('login', { error: 'Invalid email address or password' });
      }
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).render('login', { error: 'Invalid email address or password' });
      }
      req.session.user = user;
      res.redirect('/protected');
});

router.route('/admin').get(async (req, res) => {
  res.render('admin');
});

router.route('/error').get(async (req, res) => {
  res.render('error');
});

router.route('/logout').get(async (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

export default router;