async function loginUser(emailAddress, password) {
  if (!emailAddress || !password) {
    throw new Error('Both email address and password are required');
  }

  if (!validator.isEmail(emailAddress)) {
    throw new Error('Invalid email address');
  }

  const user = await usersCollection.findOne({ emailAddress: emailAddress.toLowerCase() });
  if (!user) throw new Error('Either the email address or password is invalid');
  
  const isPasswordCorrect = await bcrypt.compare(password, user.password);
  if (!isPasswordCorrect) throw new Error('Either the email address or password is invalid');

  return {
    firstName: user.firstName,
    lastName: user.lastName,
    emailAddress: user.emailAddress,
    role: user.role,
  };
}
async function registerUser(firstName, lastName, emailAddress, password, role) {
  if (!firstName || !lastName || !emailAddress || !password || !role) {
    throw new Error('All fields are required');
  }

  if (!validator.isEmail(emailAddress)) {
    throw new Error('Invalid email address');
  }

  const user = await usersCollection.findOne({ emailAddress: emailAddress.toLowerCase() });
  if (user) throw new Error('A user with this email address already exists');

  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = {
    firstName,
    lastName,
    emailAddress: emailAddress.toLowerCase(),
    password: hashedPassword,
    role,
  };

  await usersCollection.insertOne(newUser);

  return newUser;
}

export { registerUser, loginUser };