// In this file, you must perform all client-side validation for every single form input (and the role dropdown) on your pages. The constraints for those fields are the same as they are for the data functions and routes. Using client-side JS, you will intercept the form's submit event when the form is submitted and If there is an error in the user's input or they are missing fields, you will not allow the form to submit to the server and will display an error on the page to the user informing them of what was incorrect or missing.  You must do this for ALL fields for the register form as well as the login form. If the form being submitted has all valid data, then you will allow it to submit to the server for processing. Don't forget to check that password and confirm password match on the registration form!
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
  
    form.addEventListener('submit', (event) => {
      event.preventDefault();

      const username = document.querySelector('#username').value;
      const password = document.querySelector('#password').value;
      const confirmPassword = document.querySelector('#confirmPassword')?.value;
      const role = document.querySelector('#role')?.value;
      if (!username || username.length < 3) {
        alert('Username must be at least 3 characters long');
        return;
      }
  
      if (!password || password.length < 8) {
        alert('Password must be at least 8 characters long');
        return;
      }
  
      if (confirmPassword !== undefined && password !== confirmPassword) {
        alert('Passwords do not match');
        return;
      }
  
      if (role !== undefined && (role !== 'admin' && role !== 'user')) {
        alert('Invalid role selected');
        return;
      }
      form.submit();
    });
  });