// This data file should export all functions using the ES6 standard as shown in the lecture code
import { ObjectId } from 'mongodb';
import { dbConnection } from './mongoConnection.js';
const eventsCollection = 'events';
const attendeesCollection = 'attendees';
const getCollectionFn = (collection) => {
  let _col = undefined;

  return async () => {
    if (!_col) {
      const db = await dbConnection();
      _col = await db.collection(collection);
    }

    return _col;
  };
};
const createAttendee = async (eventId, firstName, lastName, emailAddress) => {
    if (!eventId || !firstName || !lastName || !emailAddress) {
      throw new Error('All fields must be provided.');
    }
    if (typeof eventId !== 'string' || typeof firstName !== 'string' || typeof lastName !== 'string' || typeof emailAddress !== 'string') {
      throw new Error('All fields must be strings.');
    }
    if (!ObjectId.isValid(eventId)) {
      throw new Error('Invalid eventId.');
    }
    const db = await dbConnection();
    const eventsCol = db.collection(eventsCollection);
    const attendeesCol = db.collection(attendeesCollection);
    const event = await eventsCol.findOne({ _id: new ObjectId(eventId) });
    if (!event) {
      throw new Error('Event does not exist.');
    }
    if (event.totalNumberOfAttendees >= event.maxCapacity) {
      throw new Error('Event is already full.');
    }
    const existingAttendee = await attendeesCol.findOne({
      eventId: new ObjectId(eventId),
      emailAddress: emailAddress,
    });
    if (existingAttendee) {
      throw new Error('Attendee with the same email already exists for this event.');
    }
    const attendee = {
      eventId: new ObjectId(eventId),
      firstName: firstName,
      lastName: lastName,
      emailAddress: emailAddress,
    };
    const result = await attendeesCol.insertOne(attendee);
    await eventsCol.updateOne(
      { _id: new ObjectId(eventId) },
      { $inc: { totalNumberOfAttendees: 1 } }
    );
    return event;
};
const getAllAttendees = async (eventId) => {
  if (!eventId) {
    throw new Error('eventId must be provided.');
  }
  if (typeof eventId !== 'string' || !ObjectId.isValid(eventId)) {
    throw new Error('Invalid eventId.');
  }
  const db = await dbConnection();
  const attendeesCol = db.collection(attendeesCollection);
  const attendees = await attendeesCol.find({ eventId: new ObjectId(eventId) }).toArray();
  return attendees;
};
const getAttendee = async (attendeeId) => {
  //Implement Code here
  if (!attendeeId || !ObjectId.isValid(attendeeId)) {
    throw new Error('Invalid attendeeId.');
  }
  const db = await dbConnection();
  const attendeesCol = db.collection(attendeesCollection);
  const attendee = await attendeesCol.findOne({ _id: new ObjectId(attendeeId) });
  if (!attendee) {
    throw new Error('Attendee does not exist.');
  }

  return attendee;
};
const removeAttendee = async (attendeeId) => {
  //Implement Code here
  if (!attendeeId || !ObjectId.isValid(attendeeId)) {
    throw new Error('Invalid attendeeId.');
  }
  const db = await dbConnection();
  const attendeesCol = db.collection(attendeesCollection);
  const attendee = await attendeesCol.findOne({ _id: new ObjectId(attendeeId) });
  if (!attendee) {
    throw new Error('Attendee does not exist.');
  }
  const eventId = attendee.eventId;
  const eventsCol = db.collection(eventsCollection);
  await attendeesCol.deleteOne({ _id: new ObjectId(attendeeId) });
  await eventsCol.updateOne(
    { _id: eventId },
    { $inc: { totalNumberOfAttendees: -1 } }
  );
  const event = await eventsCol.findOne({ _id: eventId });

  return event;
};
export { createAttendee, getAllAttendees, getAttendee, removeAttendee };

