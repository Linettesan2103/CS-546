// This data file should export all functions using the ES6 standard as shown in the lecture code
import { events } from 'linette_santana_lab6'; // Import the 'events' collection
import { ObjectId } from 'mongodb';
const create = async (
  eventName,
  eventDescription,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent
) => {
  //Implement Code here
  //Do NOT forget to initalize attendees to be an empty array and totalNumberOfAttendees to 0 on event creation
  if (!eventName || !eventDescription || !eventLocation || !contactEmail ||
    maxCapacity === undefined || priceOfAdmission === undefined || !eventDate ||
    !startTime || !endTime) {
    throw new Error('Data is incomplete');
  }
  eventName = eventName.trim();
  eventDescription = eventDescription.trim();
  contactEmail = contactEmail.trim();
  eventDate = eventDate.trim();
  startTime = startTime.trim();
  endTime = endTime.trim();

  maxCapacity = parseInt(maxCapacity, 10);
    priceOfAdmission = parseFloat(priceOfAdmission);

    if (isNaN(maxCapacity) || isNaN(priceOfAdmission)) {
      throw new Error('maximum capacity or price of admission is invalid');
    }
}
const event = {
  eventName,
  eventDescription: eventDescription,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent,
  attendees: [], 
  totalNumberOfAttendees: 0, 
};
const createEvent = async (event) => {
let result = await events().insertOne(event);
if (result.insertedCount === 1) {
  return result.ops[0];
} else {
  throw new Error('Failed to create the event.');
}
};
try {
  const createdEvent = await createEvent(event);
  console.log('Event created:', createdEvent);
} catch (error) {
  console.error('Error creating event:', error);
}
const getAll = async () => {
  //Implement Code here
  const projection = { _id: 1, eventName: 1 };

  const eventsList = await events().find({}, { projection }).toArray();

  return eventsList;
};
const get = async (eventId) => {
  //Implement Code here
  if (!id || !ObjectId.isValid(id)) {
    throw new Error('Invalid event ID.');
  }

  const event = await events().findOne({ _id: new ObjectId(id) });

  if (!event) {
    throw new Error('Event not found.');
  }

  return event;

};

const remove = async (eventId) => {
  //Implement Code here
  if (!eventId || !ObjectId.isValid(eventId)) {
    throw new Error('Invalid event ID.');
  }

  const result = await events().deleteOne({ _id: new ObjectId(eventId) });

  if (result.deletedCount === 1) {
    return 'Event deleted successfully.';
  } else {
    throw new Error('Event not found or could not be deleted.');
  }
};

const update = async (
  eventId,
  eventName,
  eventDescription,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent
) => {
  //Implement Code here
  if (!eventId || typeof eventId !== 'string' || eventId.trim() === '' || !ObjectId.isValid(eventId)) {
    throw new Error('Invalid event ID.');
  }
  // Input validation for eventName
  if (!eventName || typeof eventName !== 'string' || eventName.trim().length < 5) {
    throw new Error('Invalid eventName. It should be a string with at least 5 characters.');
  }

  // Input validation for description
  if (!eventDescription || typeof eventDescription !== 'string' || eventDescription.trim().length < 25) {
    throw new Error('Invalid description. It should be a string with at least 25 characters.');
  }

  // Input validation for contactEmail
  if (
    !contactEmail ||
    typeof contactEmail !== 'string' ||
    !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(contactEmail)
  ) {
    throw new Error('Invalid contactEmail. It should be a valid email address.');
  }

  // Input validation for maxCapacity
  if (!maxCapacity || typeof maxCapacity !== 'number' || maxCapacity <= 0 || maxCapacity % 1 !== 0) {
    throw new Error('Invalid maxCapacity. It should be a positive whole number.');
  }

  // Input validation for priceOfAdmission
  if (typeof priceOfAdmission !== 'number' || priceOfAdmission < 0 || priceOfAdmission % 0.01 !== 0) {
    throw new Error('Invalid priceOfAdmission. It should be a positive whole number or a positive two decimal place float.');
  }

  // Input validation for eventDate
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/\d{4}$/;
  if (!eventDate || typeof eventDate !== 'string' || !dateRegex.test(eventDate)) {
    throw new Error('Invalid eventDate. It should be in "MM/DD/YYYY" format.');
  }
    // Input validation for startTime and endTime
    const timeRegex = /^(0?[1-9]|1[0-2]):[0-5][0-9] [APap][Mm]$/;
    if (!startTime || typeof startTime !== 'string' || !timeRegex.test(startTime)) {
      throw new Error('Invalid startTime. It should be in "H:MM AM/PM" format.');
    }
  
    if (!endTime || typeof endTime !== 'string' || !timeRegex.test(endTime)) {
      throw new Error('Invalid endTime. It should be in "H:MM AM/PM" format.');
    }
  
    // Additional validation for start time and end time
    const startTimeAsDate = new Date(`01/01/2000 ${startTime}`);
    const endTimeAsDate = new Date(`01/01/2000 ${endTime}`);
  
    if (startTimeAsDate >= endTimeAsDate) {
      throw new Error('Invalid time range. Start time should be earlier than end time.');
    }
  const existingEvent = await events().findOne({ _id: new ObjectId(eventId) });
  if (!existingEvent) {
    throw new Error('Event not found.');
  }
  const updatedEvent = {
    eventName: eventName.trim(),
    eventDescription: eventDescription.trim(),
    eventLocation: {
      streetAddress: eventLocation.streetAddress.trim(),
      city: eventLocation.city.trim(),
      state: eventLocation.state.trim(),
      zip: eventLocation.zip.trim(),
    },
    contactEmail: contactEmail.trim(),
    maxCapacity: parseInt(maxCapacity, 10),
    priceOfAdmission: parseFloat(priceOfAdmission),
    eventDate: eventDate.trim(),
    startTime: startTime.trim(),
    endTime: endTime.trim(),
    publicEvent: Boolean(publicEvent)
  };
  const result = await events().updateOne({ _id: new ObjectId(eventId) }, { $set: updatedEvent });

  if (result.modifiedCount === 1) {
    return { ...existingEvent, ...updatedEvent };
  } else {
    throw new Error('Event not found or could not be updated.');
  }
};
