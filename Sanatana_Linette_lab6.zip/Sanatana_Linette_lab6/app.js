// This file should set up the express server as shown in the lecture code
const express = import('express');
const app = express();
const port = 3000;
// Define events
app.use('/events', require('./routes/events'));

// Define attendees
app.use('/attendees', require('./routes/attendees'));

//Express server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
