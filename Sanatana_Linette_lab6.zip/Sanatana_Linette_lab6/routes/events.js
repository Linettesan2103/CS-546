// Import the express router as shown in the lecture code
// Note: please do not forget to export the router!
import express from 'express';
import { getAll, get, create, update, remove } from '../data/events.js';
const router = express.Router();
router
  .route('/')
  .get(async (req, res) => {
    //code here for GET
    try {
      // Handle GET request for all events
      const events = await getAll();
      // Format and send the response
      const formattedEvents = events.map(event => ({
        _id: event._id,
        eventName: event.eventName,
      }));
      res.json(formattedEvents);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  })
  .post(async (req, res) => {
    //code here for POST
    try {
      const eventData = req.body;
  
      // Validate event data
      if (!eventData ||
        typeof eventData.eventName !== 'string' ||
        eventData.eventName.trim().length < 5 ||
        typeof eventData.description !== 'string' ||
        eventData.description.trim().length < 25 ||
        typeof eventData.contactEmail !== 'string' ||
        !/^\S+@\S+\.\S+$/.test(eventData.contactEmail) ||
        typeof eventData.eventLocation !== 'object' ||
        !eventData.eventLocation.streetAddress ||
        !eventData.eventLocation.city ||
        !eventData.eventLocation.state ||
        !eventData.eventLocation.zip ||
        typeof eventData.eventLocation.streetAddress !== 'string' ||
        eventData.eventLocation.streetAddress.trim().length < 3 ||
        typeof eventData.eventLocation.city !== 'string' ||
        eventData.eventLocation.city.trim().length < 3 ||
        !/^[A-Z]{2}$/.test(eventData.eventLocation.state) ||
        typeof eventData.eventLocation.zip !== 'string' ||
        !/^\d{5}$/.test(eventData.eventLocation.zip) ||
        typeof eventData.maxCapacity !== 'number' ||
        eventData.maxCapacity <= 0 ||
        typeof eventData.priceOfAdmission !== 'number' ||
        (eventData.priceOfAdmission < 0 || eventData.priceOfAdmission > 0 && eventData.priceOfAdmission.toFixed(2) != eventData.priceOfAdmission) ||
        typeof eventData.eventDate !== 'string' ||
        !/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/.test(eventData.eventDate) ||
        new Date(eventData.eventDate) <= new Date() ||
        typeof eventData.startTime !== 'string' ||
        !/^(0?[1-9]|1[0-2]):[0-5][0-9] [APap][Mm]$/.test(eventData.startTime) ||
        typeof eventData.endTime !== 'string' ||
        !/^(0?[1-9]|1[0-2]):[0-5][0-9] [APap][Mm]$/.test(eventData.endTime) ||
        new Date(`2022-01-01 ${eventData.startTime}`) >= new Date(`2022-01-01 ${eventData.endTime}`) ||
        new Date(`2022-01-01 ${eventData.endTime}`) - new Date(`2022-01-01 ${eventData.startTime}`) < 1000 * 60 * 30 ||
        typeof eventData.publicEvent !== 'boolean'
      ) {
        res.status(400).json({ error: 'Bad Request' });
      } else {
        // If the data is valid, create the event
        const newEvent = await createEvent(eventData);
        res.status(200).json(newEvent);
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

router
  .route('/:eventId')
  .get(async (req, res) => {
    //code here for GET
    try {
      const eventId = req.params.eventId;

      // Validate the eventId
      if (!isValidObjectId(eventId)) {
        res.status(400).json({ error: 'Invalid eventId' });
        return;
      }

      // Find the event by its ID
      const event = await Event.findById(eventId);

      // If no event is found, respond with a 404 status code
      if (!event) {
        res.status(404).json({ error: 'Event not found' });
        return;
      }

      // Respond with the event data and a 200 status code
      res.status(200).json({
        _id: event._id,
        eventName: event.eventName,
        description: event.description,
        eventLocation: event.eventLocation,
        contactEmail: event.contactEmail,
        maxCapacity: event.maxCapacity,
        priceOfAdmission: event.priceOfAdmission,
        eventDate: event.eventDate,
        startTime: event.startTime,
        endTime: event.endTime,
        publicEvent: event.publicEvent,
        attendees: event.attendees,
        totalNumberOfAttendees: event.totalNumberOfAttendees,
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  })
  .delete(async (req, res) => {
    //code here for DELETE
    try {
      const eventId = req.params.eventId;
  
      // Validate ObjectId
      if (!ObjectId.isValid(eventId)) {
        return res.status(400).json({ error: 'Invalid eventId' });
      }
  
      // Find the event by ID and delete it
      const deletedEvent = await Event.findByIdAndDelete(eventId);
  
      // Check if the event exists
      if (!deletedEvent) {
        return res.status(404).json({ error: 'Event not found' });
      }
  
      res.status(200).json({ eventName: deletedEvent.eventName, deleted: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  })
  .put(async (req, res) => {
    //code here for PUT
    try {
      const eventId = req.params.eventId;
      const eventData = req.body;
  
      // Validate ObjectId
      if (!ObjectId.isValid(eventId)) {
        return res.status(400).json({ error: 'Invalid eventId' });
      }
  
      // Find the event by ID
      const existingEvent = await Event.findById(eventId);
  
      // Check if the event exists
      if (!existingEvent) {
        return res.status(404).json({ error: 'Event not found' });
      }
  
      // Check if any data is missing
      const requiredFields = ['eventName', 'description', 'eventLocation', 'contactEmail', 'maxCapacity', 'priceOfAdmission', 'eventDate', 'startTime', 'endTime', 'publicEvent'];
      for (const field of requiredFields) {
        if (!eventData[field]) {
          return res.status(400).json({ error: `Missing field: ${field}` });
        }
      }
  
      // Validate event data
      if (eventData.eventName.length < 5) {
        return res.status(400).json({ error: 'eventName should be at least 5 characters' });
      }
  
      if (eventData.description.length < 25) {
        return res.status(400).json({ error: 'description should be at least 25 characters' });
      }
  
      if (!validator.isEmail(eventData.contactEmail)) {
        return res.status(400).json({ error: 'Invalid contactEmail format' });
      }
  
      if (!moment(eventData.eventDate, 'MM/DD/YYYY', true).isValid()) {
        return res.status(400).json({ error: 'Invalid eventDate format' });
      }
  
      const currentDate = moment();
      if (moment(eventData.eventDate, 'MM/DD/YYYY').isSameOrBefore(currentDate)) {
        return res.status(400).json({ error: 'eventDate should be in the future' });
      }
  
      if (!moment(eventData.startTime, 'h:mmA', true).isValid() || !moment(eventData.endTime, 'h:mmA', true).isValid()) {
        return res.status(400).json({ error: 'Invalid time format (use h:mmAM/PM)' });
      }
  
      if ( moment(eventData.startTime, 'h:mmA').isSameOrAfter(moment(eventData.endTime, 'h:mmA'))) {
        return res.status(400).json({ error: 'startTime should be before endTime' });
      }
  
      if ( moment(eventData.endTime, 'h:mmA').isSameOrBefore(moment(eventData.startTime, 'h:mmA'))){
        return res.status(400).json({ error: 'endTime should be after startTime' });
      }
  
      if (eventData.maxCapacity <= 0 || !Number.isInteger(eventData.maxCapacity)) {
        return res.status(400).json({ error: 'maxCapacity should be a positive whole number' });
      }
  
      if (eventData.priceOfAdmission < 0) {
        return res.status(400).json({ error: 'priceOfAdmission should be a non-negative number' });
      }
  
      if (!validator.isObject(eventData.eventLocation) ||
          !eventData.eventLocation.streetAddress || !eventData.eventLocation.city ||
          !eventData.eventLocation.state || !eventData.eventLocation.zip) {
        return res.status(400).json({ error: 'Invalid eventLocation' });
      }
  
      if (eventData.eventLocation.streetAddress.length < 3 ||
          eventData.eventLocation.city.length < 3 ||
          eventData.eventLocation.state.length !== 2 ||
          !/^\d{5}$/.test(eventData.eventLocation.zip)) {
        return res.status(400).json({ error: 'Invalid eventLocation fields' });
      }
  
      // Update the event
      existingEvent.set(eventData);
      const updatedEvent = await existingEvent.save();
  
      res.status(200).json(updatedEvent);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

