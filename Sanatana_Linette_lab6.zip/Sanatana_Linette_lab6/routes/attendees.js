// Import the express router as shown in the lecture code
// Note: please do not forget to export the router!

router
  .route('/:eventId')
  .get(async (req, res) => {
    //code here for GET
    try {
      const eventId = req.params.eventId;
  
      // Validate eventId as ObjectId
      if (!ObjectId.isValid(eventId)) {
        return res.status(400).json({ error: 'Invalid eventId' });
      }
  
      // Find the event by ID
      const event = await Event.findById(eventId);
  
      // Check if the event exists
      if (!event) {
        return res.status(404).json({ error: 'Event not found' });
      }
  
      // Return the array of attendees for the event
      res.status(200).json(event.attendees);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  })
  .post(async (req, res) => {
    //code here for POST
    try {
      const eventId = req.params.eventId;
  
      // Validate eventId as ObjectId
      if (!ObjectId.isValid(eventId)) {
        return res.status(400).json({ error: 'Invalid eventId' });
      }
  
      // Find the event by ID
      const event = await Event.findById(eventId);
  
      // Check if the event exists
      if (!event) {
        return res.status(404).json({ error: 'Event not found' });
      }
  
      // Extract attendee data from the request body
      const { firstName, lastName, emailAddress } = req.body;
  
      // Validate that all fields are provided
      if (!firstName || !lastName || !emailAddress) {
        return res.status(400).json({ error: 'All fields must be provided' });
      }
  
      // Validate the data types and values
      if (typeof firstName !== 'string' || typeof lastName !== 'string' || typeof emailAddress !== 'string' ||
          firstName.trim() === '' || lastName.trim() === '' || emailAddress.trim() === '') {
        return res.status(400).json({ error: 'Invalid field values' });
      }
  
      // Create a new attendee
      const newAttendee = {
        firstName,
        lastName,
        emailAddress,
      };
  
      // Add the new attendee to the event's attendees array
      event.attendees.push(newAttendee);
  
      // Update the total number of attendees
      event.totalNumberOfAttendees = event.attendees.length;
  
      // Save the updated event to the database
      await event.save();
  
      // Return the updated event data with a 200 status code
      res.status(200).json(event);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

router
  .route('/attendee/:attendeeId')
  .get(async (req, res) => {
    //code here for GET
    try {
      const attendeeId = req.params.attendeeId;
  
      // Validate attendeeId as ObjectId
      if (!ObjectId.isValid(attendeeId)) {
        return res.status(400).json({ error: 'Invalid attendeeId' });
      }
  
      // Find the attendee by ID
      const attendee = await Attendee.findById(attendeeId);
  
      // Check if the attendee exists
      if (!attendee) {
        return res.status(404).json({ error: 'Attendee not found' });
      }
  
      // Return the attendee as a single object with a 200 status code
      res.status(200).json(attendee);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  })
  .delete(async (req, res) => {
    //code here for DELETE
    try {
      const attendeeId = req.params.attendeeId;
  
      // Validate attendeeId as ObjectId
      if (!ObjectId.isValid(attendeeId)) {
        return res.status(400).json({ error: 'Invalid attendeeId' });
      }

      const attendee = await Attendee.findById(attendeeId);
      if (!attendee) {
        return res.status(404).json({ error: 'Attendee not found' });
      }
      const eventId = attendee.eventId;
      await attendee.delete();
      const event = await Event.findById(eventId);
      if (event) {
        event.attendees = event.attendees.filter((a) => a._id.toString() !== attendeeId);
        event.totalNumberOfAttendees = event.attendees.length;
        await event.save();
      }
      res.status(200).json(event);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
