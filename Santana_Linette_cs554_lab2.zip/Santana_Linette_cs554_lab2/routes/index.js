const spaceXroutes = require('./spacex.js');

const constructorMethod = (app) => {
  app.use('/', spaceXroutes);

  app.use('*', (req, res) => {
    res.json({error: 'Route no valid'});
  });
};
module.exports = constructorMethod;