const express = require('express');
const router = express.Router();
const redis = require('redis');
const client = redis.createClient();
const axios = require('axios');
client.connect().then(() => {});

router.get('/api/rockets', async (req, res) => {
    console.log('data from SpaceX API');
    const response = await axios.get('https://api.spacexdata.com/v4/rockets');
    client.set('rockets', JSON.stringify(response.data), () => {
      res.json(response.data);
    });
  });
router.get('/api/launches', async (req, res) => {
    console.log('data from SpaceX API');
    const response = await axios.get('https://api.spacexdata.com/v4/launches');
    client.set('launches', JSON.stringify(response.data), () => {
      res.json(response.data);
    });
  });
router.get('/api/launches/:id', async (req, res) => {
const { id } = req.params;
console.log(` data from SpaceX API for launch ${id}`);
try {
    let { data } = await axios.get(`https://api.spacexdata.com/v4/launches/${id}`);
    const launchesData = JSON.stringify(data);
    client.set(`launch:${id}`, launchesData, () => {
        client.set(`history:${id}`, launchesData, () => {
            res.json(data);
        });
    });
} catch (error) {
    console.error(`Failed data for launch ${id}`);
    res.status(404).json({ error: 'launch not found' });
}
});
router.get('/api/capsules', async (req, res) => {
    console.log('data from SpaceX API');
    const response = await axios.get('https://api.spacexdata.com/v4/capsules');
    client.set('capsules', JSON.stringify(response.data), () => {
      res.json(response.data);
    });
  });
router.get('/api/capsules/:id', async (req, res) => {
    const { id } = req.params;
    console.log(`data from SpaceX API for capsule ${id}`);
    try {
        let { data } = await axios.get(`https://api.spacexdata.com/v4/capsules/${id}`);
        const capsulesData = JSON.stringify(data);
        client.set(`capsule:${id}`, capsulesData, () => {
            client.set(`history:${id}`, capsulesData, () => {
                res.json(data);
            });
        });
    } catch (error) {
        console.error(`Failed data for capsule ${id}`);
        res.status(404).json({ error: 'capsule not found' });
    }
    });
router.get('/api/rockets/history', (req, res) => {
    client.lRange('recentlyViewed', 0, 19, (err, reply) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'An error occurred' });
        }
        try {
            const data = reply.map(item => JSON.parse(item));
            res.json(data);
        } catch (parseError) {
            console.error(parseError);
            res.status(500).json({ error: 'Failed data' });
        }
    });
});
router.get('/api/rockets/:id', async (req, res) => {
    const { id } = req.params;
    console.log(`data from SpaceX API for rocket ${id}`);
    try {
        let { data } = await axios.get(`https://api.spacexdata.com/v4/rockets/${id}`);
        const rocketData = JSON.stringify(data);
        client.lPush('recentlyViewed', rocketData, (err, reply) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'An error occurred' });
            }
            res.json(data);
        });
    } catch (error) {
        console.error(`Failed to fetch data for rocket ${id}`);
        res.status(404).json({ error: 'Rocket not found' });
    }
});
module.exports = router;
