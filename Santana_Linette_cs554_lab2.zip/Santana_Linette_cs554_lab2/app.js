const express = require('express');
const app = express();
const static = express.static(__dirname + '/public');
const configRoutes = require('./routes');
const exphbs = require('express-handlebars');
const redis = require('redis');
const client = redis.createClient();
client.connect().then(() => {});
const handlebarsInstance = exphbs.create({
    defaultLayout: 'main'
  });
  
  app.use('/public', static);
  app.use(express.json());
  app.use(express.urlencoded({extended: true}));


app.use('/api/rockets', async (req, res, next) => {
    if (req.originalUrl === '/api/rockets') {
        let exists = await client.exists('rockets');
        if (exists) {
          //if we do have it in cache, send the raw html from cache
          console.log('Rocket List from cache');
          let rockets = await client.get('rockets');
          console.log('Sending HTML from Redis....');
          res.send(rockets);
          return;
        } else {
          next();
        }
      } else {
        next();
      }
});
app.use('/api/rockets/:id', async (req, res, next) => {
    let exists = await client.exists(`rocket:${req.params.id}`);
    if (exists) {
    //if we do have it in cache, send the raw html from cache
    console.log('Rockets in Cache');
    let rocketsid = await client.get(`rocket:${req.params.id}`);
    console.log('Sending HTML from Redis....');
    res.send(rocketsid);
    } else {
    next();
    }
});
  app.use('/api/launches', async (req, res, next) => {
    if (req.originalUrl === '/api/launches') {
        let exists = await client.exists('launches');
        if (exists) {
          //if we do have it in cache, send the raw html from cache
          console.log('Launches List from cache');
          let launches = await client.get('launches');
          console.log('Sending HTML from Redis....');
          res.send(launches);
          return;
        } else {
          next();
        }
      } else {
        next();
      }
});
  app.use('/api/launches/:id', async (req, res, next) => {
    let exists = await client.exists(`launch:${req.params.id}`);
    if (exists) {
    //if we do have it in cache, send the raw html from cache
    console.log('Launches in Cache');
    let launchesid = await client.get(`launch:${req.params.id}`);
    console.log('Sending HTML from Redis....');
    res.send(launchesid);
    } else {
    next();
    }
});
  app.use('/api/capsules', async (req, res, next) => {
    if (req.originalUrl === '/api/capsules') {
        let exists = await client.exists('capsules');
        if (exists) {
          //if we do have it in cache, send the raw html from cache
          console.log('Capsules List from cache');
          let capsules = await client.get('capsules');
          console.log('Sending HTML from Redis....');
          res.send(capsules);
          return;
        } else {
          next();
        }
      } else {
        next();
      }
});
  app.use('/api/capsules/:id', async (req, res, next) => {
    let exists = await client.exists(`capsule:${req.params.id}`);
    if (exists) {
    //if we do have it in cache, send the raw html from cache
    console.log('Capsules in Cache');
    let capsulesid = await client.get(`capsule:${req.params.id}`);
    console.log('Sending HTML from Redis....');
    res.send(capsulesid);
    } else {
    next();
    }
});
app.engine('handlebars', exphbs.engine({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');
configRoutes(app);
app.listen(3000, async () => {
  console.log("We've now got a server!");
  console.log('Your routes will be running on http://localhost:3000');
});
