import { GraphQLError } from 'graphql';
import { artists as artistsCollection, albums as albumsCollection, recordcompanies as recordCompaniesCollection } from './config/mongoCollections.js';
import { v4 as uuid } from 'uuid';
import redis from 'redis';
import bluebird from 'bluebird';
bluebird.promisifyAll(redis);
const client = redis.createClient();

client.connect().then(() => {
  console.log('Connected to Redis');
}).catch((err) => {
  console.log("Error " + err);
});

export const resolvers = {
  Query: {
    artists: async () => {
      const artists = await artistsCollection();
      const allArtists = await artists.find().toArray();

      if (!allArtists || allArtists.length === 0) {
        throw new GraphQLError('artist not found', {
          extensions: { code: 'INTERNAL_SERVER_ERROR' }
        });
      } else {
        client.set('artists', JSON.stringify(allArtists), 'EX', 60 * 60);
        return allArtists;
      }
    },
    albums: async () => {
      const albums = await albumsCollection();
      const allAlbums = await albums.find().toArray();
      if (!allAlbums|| allAlbums.length === 0) {
        throw new GraphQLError('album Not Found', {
          extensions: { code: 'NOT_FOUND' }
        });
      } else {
        client.set('artists', JSON.stringify(allArtists), 'EX', 60 * 60);
        return allArtists;
      }
    },
    recordCompanies: async () => {
      const recordCompanies = await recordCompaniesCollection();
      const allRecordCompany = await recordCompanies.find().toArray();
      if (!allRecordCompany|| allRecordCompany.length === 0) {
        throw new GraphQLError('Record Company Not Found', {
          extensions: { code: 'NOT_FOUND' }
        });
      }else {
        client.set('artists', JSON.stringify(allArtists), 'EX', 60 * 60);
        return allArtists;
      }
    }, 
    getArtistById: async (_, args) => {
      const gotArtist = await client.getAsync(`artist:${args._id}`);
      if (gotArtist) {
        return JSON.parse(gotArtist);
      } else {
        const artists = await artistsCollection();
        const artist = await artists.findOne({_id: args._id});
        if (!artist) {
          throw new GraphQLError('Artist Not Found', {
            extensions: {code: 'NOT_FOUND'}
          });
        }
        await client.setAsync(`artist:${args._id}`, JSON.stringify(artist));
        return artist;
      }
    },
    getAlbumById: async (_, args) => {
      const gotAlbum = await client.getAsync(`album:${args._id}`);
      if (gotAlbum) {
        return JSON.parse(gotAlbum);
      } else {
        const albums = await albumsCollection();
        const album = await albums.findOne({_id: args._id});
        if (!album) {
          throw new GraphQLError('Album Not Found', {
            extensions: {code: 'NOT_FOUND'}
          });
        }
        await client.setAsync(`album:${args._id}`, JSON.stringify(album));
        return album;
      }
    },
    getCompanyById: async (_, args) => {
      const gotCompany = await client.getAsync(`company:${args._id}`);
      if (gotCompany) {
        return JSON.parse(gotCompany);
      } else {
        const recordCompanies = await recordCompaniesCollection();
        const recordCompany = await recordCompanies.findOne({_id: args._id});
        if (!recordCompany) {
          throw new GraphQLError('Record Company Not Found', {
            extensions: {code: 'NOT_FOUND'}
          });
        }
        await client.setAsync(`company:${args._id}`, JSON.stringify(recordCompany));
        return recordCompany;
      }
    },
    getSongsByArtistId: async (_, { artistId }) => {
      const key = 'songs:' + artistId;
      const gotSongs = await client.lrangeAsync(key, 0, -1);
    
      if (gotSongs.length > 0) {
        return gotSongs.map(song => JSON.parse(song));
      }
      const artists = await artistsCollection();
      const artist = await artists.findOne({ _id: artistId });
      if (!artist) {
        throw new GraphQLError('Artist Not Found', {
          extensions: { code: 'NOT_FOUND' }
        });
      }
      const songs = artist.albums.flatMap(album => album.songs);
      songs.forEach(async song => {
        await client.rpushAsync(key, JSON.stringify(song));
      });
      return songs;
    },
    albumsByGenre: async (_, { genre }, { albumsCollection, redisClient }) => {
      if (!genre || !genre.trim()) {
        throw new GraphQLError('Genre cannot be empty or just spaces', {
          extensions: { code: 'BAD_USER_INPUT' }
        });
      }
      genre = genre.toLowerCase();
      const gotAlbums = await redisClient.lrangeAsync(genre, 0, -1);
      if (gotAlbums.length > 0) {
        return gotAlbums.map(album => JSON.parse(album));
      }
      const albums = await albumsCollection.find({ genre: new RegExp('^' + genre + '$', 'i') }).toArray();
      albums.forEach(async album => {
        await redisClient.rpushAsync(genre, JSON.stringify(album));
      });

      return albums;
    },
    companyByFoundedYear: async (_, { min, max }, { recordCompaniesCollection, redisClient }) => {
      if (min < 1900 || max <= min || max >= 2025) {
        throw new GraphQLError('Invalid year range', {
          extensions: { code: 'BAD_USER_INPUT' }
        });
      }
      const key = `foundedYear:${min}-${max}`;
      const gotCompanies = await redisClient.lrangeAsync(key, 0, -1);
      if (gotCompanies.length > 0) {
        return gotCompanies.map(company => JSON.parse(company));
      }
      const companies = await recordCompaniesCollection.find({ foundedYear: { $gte: min, $lte: max } }).toArray();
      companies.forEach(async company => {
        await redisClient.rpushAsync(key, JSON.stringify(company));
      });

      return companies;
    },
    searchArtistByArtistName: async (_, { searchTerm }, { artistsCollection, redisClient }) => {
      if (!searchTerm || !searchTerm.trim()) {
        throw new GraphQLError('Search term cannot be empty or just spaces', {
          extensions: { code: 'BAD_USER_INPUT' }
        });
      }
      searchTerm = searchTerm.toLowerCase();
      const gotArtists = await redisClient.lrangeAsync(searchTerm, 0, -1);
      if (gotArtists.length > 0) {
        return gotArtists.map(artist => JSON.parse(artist));
      }
      const artists = await artistsCollection.find({ name: new RegExp(searchTerm, 'i') }).toArray();
      artists.forEach(async artist => {
        await redisClient.rpushAsync(searchTerm, JSON.stringify(artist));
      });
    
      return artists;
    },
  },
  Artist: {
    numOfAlbums: async (parentValue) => {
        console.log(`parentValue in artist`, parentValue);
        const albums = await albumsCollection();
        const numOfAlbums = await albums.count({
          artistId: parentValue._id
        });
        return numOfAlbums;
    },
    albums: async (parentValue) => {
        const album = await albumsCollection();
        const albums = await album
          .find({albumId: parentValue._id})
          .toArray();
        return albums;
    }
  },
  Artist: {
    numOfAlbums: async (parentValue) => {
      const albums = await albumsCollection();
      const numOfAlbums = await albums.countDocuments({
        artistId: parentValue._id
      });
      return numOfAlbums;
    },
    albums: async (parentValue) => {
      const album = await albumsCollection();
      const albums = await album
        .find({artistId: parentValue._id})
        .toArray();
      return albums;
    }
  },
  Album: {
    artist: async (parentValue) => {
      const artists = await artistsCollection();
      const artist = await artists
        .findOne({_id: parentValue.artistId});
      return artist;
    },
    recordCompany: async (parentValue) => {
      const recordCompanies = await recordCompaniesCollection();
      const recordCompany = await recordCompanies
        .findOne({_id: parentValue.companyId});
      return recordCompany;
    }
  },
  RecordCompany:{
    numOfAlbums: async (parentValue) => {
      const albums = await albumsCollection();
      const numOfAlbums = await albums.countDocuments({
        companyId: parentValue._id
      });
      return numOfAlbums;
    },
    albums: async (parentValue) => {
      const album = await albumsCollection();
      const albums = await album
        .find({companyId: parentValue._id})
        .toArray();
      return albums;
    }
  },
  Mutation: {
      addArtist: async (_, args) => {
          const artist = await artistsCollection();
          if (!args.name.trim()) {
              throw new GraphQLError('Name cannot be just spaces', {
                extensions: {code: 'BAD_INPUT'}
              });
            }
          let dateParts = args.dateFormed.split("/");
          let month = parseInt(dateParts[0]);
          let day = parseInt(dateParts[1]);
          let year = parseInt(dateParts[2]);
            
          if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1 || isNaN(month) || isNaN(day) || isNaN(year)) {
          throw new GraphQLError('Invalid date format', {
              extensions: {code: 'BAD_USER_INPUT'}
              });
          }
            
          let date = new Date(year, month - 1, day);
          if (date.getMonth() !== month - 1 || date.getDate() !== day || date.getFullYear() !== year) {
          throw new GraphQLError('Invalid date', {
              extensions: {code: 'BAD_USER_INPUT'}
              });
          }
          if (!args.members.every(member => /^[A-Za-z\s]+$/.test(member))) {
          throw new GraphQLError('Members should only contain letters A-Z (all cases) and no numbers', {
              extensions: {code: 'BAD_USER_INPUT'}
              });
          }
          const newartist = {
            _id: uuid(),
            name: args.name,
            dateFormed: args.dateFormed,
            albums: [],
            members: args.members,
            numOfAlbums: 0,
          };
          let insertedArtist = await artist.insertOne(newartist);
          if (!insertedArtist.acknowledged || !insertedArtist.insertedId) {
            throw new GraphQLError(`Could not Add artist`, {
              extensions: {code: 'INTERNAL_SERVER_ERROR'}
            });
          }
          client.set(newartist._id.toString(), JSON.stringify(newartist));
          return newartist;
      },
  editArtist: async (_, args) => {
      const artists = await artistsCollection();
      let newArtist = await artists.findOne({_id: args._id});
      if (newArtist) {
          if (args.name && args.name.trim()) {
              newArtist.name = args.name;
          }
      if (args.dateFormed) {
      let dateParts = args.dateFormed.split("/");
      let month = parseInt(dateParts[0]);
      let day = parseInt(dateParts[1]);
      let year = parseInt(dateParts[2]);
      if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1 || isNaN(month) || isNaN(day) || isNaN(year)) {
          throw new GraphQLError('Invalid date format', {
          extensions: {code: 'BAD_USER_INPUT'}
          });
      }
      let date = new Date(year, month - 1, day);
      if (date.getMonth() !== month - 1 || date.getDate() !== day || date.getFullYear() !== year) {
          throw new GraphQLError('Invalid date', {
          extensions: {code: 'BAD_USER_INPUT'}
          });
      }
      newArtist.dateFormed = args.dateFormed;
      }
      if (args.members && args.members.every(member => /^[A-Za-z\s]+$/.test(member))) {
          newArtist.members = args.members;
        } else if (args.members) {
          throw new GraphQLError('Members should only contain letters A-Z (all cases) and no numbers', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        await artists.updateOne({_id: args._id}, {$set: newArtist});
        client.set(newArtist._id.toString(), JSON.stringify(newArtist));
      } else {
        throw new GraphQLError(
          `Could not update artist with _id of ${args._id}`,
          {
            extensions: {code: 'NOT_FOUND'}
          }
        );
      } 
      return newArtist;
    },
    removeArtist: async (_, args) => {
      const artists= await artistsCollection();
      const albums = await albumsCollection();
      const deletedArtist = await artists.findOneAndDelete({_id: args._id});

      if (deletedArtist.value) {
        await albums.deleteMany({artistId: args._id});
        client.del(deletedArtist.value._id.toString());
        for (const album of deletedArtist.value.albums) {
          client.del(album._id.toString());
        }
        client.del('allArtists');
        return deletedArtist.value;
      } else {
        throw new GraphQLError(
          `Could not delete artist with _id of ${args._id}`,
          {
            extensions: {code: 'NOT_FOUND'}
          }
        );
      }
    },
    addCompany: async (_, args) => {
      const companies = await recordCompaniesCollection();
      if (!args.name.trim() || !/^[A-Za-z\s]+$/.test(args.name)) {
        throw new GraphQLError('Name should only contain letters A-Z (all cases) and no numbers', {
          extensions: {code: 'BAD_USER_INPUT'}
        });
      }
      if (args.founded_year < 1900 || args.founded_year >= 2025 || !Number.isInteger(args.founded_year)) {
        throw new GraphQLError('Invalid year. It should be an integer within 1900 <= founded_year < 2025', {
          extensions: {code: 'BAD_USER_INPUT'}
        });
      }
      if (!args.country.trim()) {
        throw new GraphQLError('Country cannot be just spaces', {
          extensions: {code: 'BAD_USER_INPUT'}
        });
      }
      const newCompany = {
        _id: uuid(),
        name: args.name,
        founded_year: args.founded_year,
        country: args.country,
        albums: [],
        numOfAlbums: 0,
      };
      let insertedCompany = await companies.insertOne(newCompany);
      if (!insertedCompany.acknowledged || !insertedCompany.insertedId) {
        throw new GraphQLError(`Could not add company`, {
          extensions: {code: 'INTERNAL_SERVER_ERROR'}
        });
      }
      client.set(newCompany._id.toString(), JSON.stringify(newCompany));
      return newCompany;
    },
    editCompany: async (_, args) => {
      const companies = await recordCompaniesCollection();
      let newCompany = await companies.findOne({_id: args._id});
    
      if (newCompany) {
        if (args.name && args.name.trim() && /^[A-Za-z\s]+$/.test(args.name)) {
          newCompany.name = args.name;
        } else if (args.name) {
          throw new GraphQLError('Name should only contain letters A-Z (all cases) and no numbers', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        if (args.founded_year && (args.founded_year < 1900 || args.founded_year >= 2025 || !Number.isInteger(args.founded_year))) {
          throw new GraphQLError('Invalid year. It should be an integer within 1900 <= founded_year < 2025', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        } else if (args.founded_year) {
          newCompany.founded_year = args.founded_year;
        }
        if (args.country && !args.country.trim()) {
          throw new GraphQLError('Country cannot be just spaces', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        } else if (args.country) {
          newCompany.country = args.country;
        }
        await companies.updateOne({_id: args._id}, {$set: newCompany});
        client.set(newCompany._id.toString(), JSON.stringify(newCompany));
        } else {
          throw new GraphQLError(
            `Could not update company with _id of ${args._id}`,
            {
              extensions: {code: 'NOT_FOUND'}
            }
          );
        }
        return newCompany;
    },
    removeCompany: async (_, args) => {
      const companies = await recordCompaniesCollection();
      const albums = await albumsCollection();
      const deletedCompany = await companies.findOneAndDelete({_id: args._id});
      if (!deletedCompany.value) {
        throw new GraphQLError(
          `Could not delete company with _id of ${args._id}`,
          {
            extensions: {code: 'NOT_FOUND'}
          }
        );
      }
      await albums.deleteMany({companyId: args._id});
      client.del(args._id.toString());
      const companyAlbums = await albums.find({companyId: args._id}).toArray();
      companyAlbums.forEach(album => {
        client.del(album._id.toString());
      });
 
      client.del('allCompanies');
    
      return deletedCompany.value;
    },
    addAlbum: async (_, args) => {
        const albums = await albumsCollection();
        const artists = await artistsCollection();
        const companies = await recordCompaniesCollection();
        const Artist = await artists.findOne({_id: args.artistId});
        const RecordCompany = await companies.findOne({_id: args.companyId});
        if (!Artist || !RecordCompany) {
          throw new GraphQLError(
            `Artist or record company does not exist`,
            {
              extensions: {code: 'NOT_FOUND'}
            }
          );
        }
        if (!args.title.trim()) {
          throw new GraphQLError('Title cannot be just spaces', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        if (!['POP', 'ROCK', 'JAZZ', 'CLASSICAL', 'COUNTRY'].includes(args.genre)) {
          throw new GraphQLError('Invalid genre. It should be one of the following: POP, ROCK, JAZZ, CLASSICAL, COUNTRY', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        args.songs.forEach(song => {
          if (!song.trim() || !/^[A-Za-z\s]+$/.test(song)) {
            throw new GraphQLError('Invalid song. It should only contain letters A-Z (all cases) and no numbers', {
              extensions: {code: 'BAD_USER_INPUT'}
            });
          }
        });
        let dateParts = args.releaseDate.split("/");
        let month = parseInt(dateParts[0]);
        let day = parseInt(dateParts[1]);
        let year = parseInt(dateParts[2]);
        if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1 || isNaN(month) || isNaN(day) || isNaN(year)) {
          throw new GraphQLError('Invalid date format', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        let date = new Date(year, month - 1, day);
        if (date.getMonth() !== month - 1 || date.getDate() !== day || date.getFullYear() !== year) {
          throw new GraphQLError('Invalid date', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        if (!args.songs.every(song => /^[A-Za-z\s]+$/.test(song))) {
          throw new GraphQLError('Songs should only contain letters A-Z (all cases) and no numbers', {
            extensions: {code: 'BAD_USER_INPUT'}
          });
        }
        let newAlbum = {
            _id: uuid(),
            title: args.title,
            releaseDate: args.releaseDate,
            genre: args.genre,
            artist: Artist,
            recordCompany: RecordCompany,
            songs: args.songs,
          };
        const result = await albums.insertOne(newAlbum);
        if (!result.acknowledged || !result.insertedId) {
            throw new GraphQLError(`Could not add album`, {
              extensions: {code: 'INTERNAL_SERVER_ERROR'}
            });
          }
          client.set(newAlbum._id.toString(), JSON.stringify(newAlbum));
          return newAlbum;
    },
    editAlbum: async (_, args) => {
        const albums = await albumsCollection();
        const artists = await artistsCollection();
        const companies = await recordCompaniesCollection();
        let newAlbum = await albums.findOne({_id: args._id});
        if (newAlbum) {
          if (args.title && args.title.trim()) {
            newAlbum.title = args.title;
          }
          if (args.releaseDate) {
            let dateParts = args.releaseDate.split("/");
            let month = parseInt(dateParts[0]);
            let day = parseInt(dateParts[1]);
            let year = parseInt(dateParts[2]);
            if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1 || isNaN(month) || isNaN(day) || isNaN(year)) {
              throw new GraphQLError('Invalid date format', {
                extensions: {code: 'BAD_USER_INPUT'}
              });
            }
            let date = new Date(year, month - 1, day);
            if (date.getMonth() !== month - 1 || date.getDate() !== day || date.getFullYear() !== year) {
              throw new GraphQLError('Invalid date', {
                extensions: {code: 'BAD_USER_INPUT'}
              });
            }
            newAlbum.releaseDate = args.releaseDate;
          }
          if (args.genre && Object.values(MusicGenre).includes(args.genre)) {
            newAlbum.genre = args.genre;
          }
          if (args.songs && args.songs.every(song => /^[A-Za-z\s]+$/.test(song))) {
            newAlbum.songs = args.songs;
          } else if (args.songs) {
            throw new GraphQLError('Songs should only contain letters A-Z (all cases) and no numbers', {
              extensions: {code: 'BAD_USER_INPUT'}
            });
          }
          if (args.artistId) {
            const newArtist = await artists.findOne({_id: args.artistId});
            if (newArtist) {
              const oldArtist = await artists.findOne({_id: newAlbum.artist._id});
              oldArtist.albums = oldArtist.albums.filter(albumId => albumId !== args._id);
              await artists.updateOne({_id: oldArtist._id}, {$set: oldArtist});
              client.del(oldArtist._id.toString());
      
              newArtist.albums.push(args._id);
              await artists.updateOne({_id: newArtist._id}, {$set: newArtist});
              client.del(newArtist._id.toString());
      
              newAlbum.artist = newArtist;
            }
          }
          if (args.companyId) {
            const newCompany = await companies.findOne({_id: args.companyId});
            if (newCompany) {
              const oldCompany = await companies.findOne({_id: newAlbum.recordCompany._id});
              oldCompany.albums = oldCompany.albums.filter(albumId => albumId !== args._id);
              await companies.updateOne({_id: oldCompany._id}, {$set: oldCompany});
              client.del(oldCompany._id.toString());
              newCompany.albums.push(args._id);
              await companies.updateOne({_id: newCompany._id}, {$set: newCompany});
              client.del(newCompany._id.toString());
      
              newAlbum.recordCompany = newCompany;
            }
          }
          await albums.updateOne({_id: args._id}, {$set: newAlbum});
          client.set(newAlbum._id.toString(), JSON.stringify(newAlbum));
        } else {
          throw new GraphQLError(
            `Could not update album with _id of ${args._id}`,
            {
              extensions: {code: 'NOT_FOUND'}
            }
          );
        }
        return newAlbum;
    },
  removeAlbum: async (_, args) => {
      const albums = await albumsCollection();
      const artists = await artistsCollection();
      const companies = await recordCompaniesCollection();
    
      const deletedAlbum = await albums.findOneAndDelete({_id: args._id});
      if (!deletedAlbum) {
        throw new GraphQLError(
          `Could not delete album with _id of ${args._id}`,
          {
            extensions: {code: 'NOT_FOUND'}
          }
        );
      }
      const artist = await artists.findOne({_id: deletedAlbum.artist._id});
      artist.albums = artist.albums.filter(albumId => albumId !== args._id);
      await artists.updateOne({_id: artist._id}, {$set: artist});
      client.del(artist._id.toString());
      const company = await companies.findOne({_id: deletedAlbum.recordCompany._id});
      company.albums = company.albums.filter(albumId => albumId !== args._id);
      await companies.updateOne({_id: company._id}, {$set: company});
      client.del(company._id.toString());
      client.del(args._id.toString());
      client.del('allAlbums');
    
      return deletedAlbum; 
  }
}
};
