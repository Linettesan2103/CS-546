import {dbConnection, closeConnection} from '../config/mongoConnections.js';
import {artists,albums,recordcompanies} from '../config/mongoCollections.js';
import {v4 as uuid} from 'uuid';

const main = async () => {
  const db = await dbConnection();
  await db.dropDatabase();
  const artistsCollection = await artists();
  const albumsCollection = await albums();
  const recordCompaniesCollection = await recordcompanies();
  await artistsCollection.insertMany([
        {
            _id: uuid.v4(),
            name: 'Adele',
            dateFormed: '09/03/21',
            members: ['adele'],
            albums: [albums],
            numOfAlbums: 3
        },
        {
            _id: uuid.v4(),
            name: 'bts',
            dateFormed: '12/09/19',
            members: ['v', 'rm', 'suga', 'jk', ],
            albums: [albums],
            numOfAlbums: 3
        }
        ]);
        await albumsCollection.insertMany([    
        {
            _id: uuid.v4(),
            title: 'red',
            releaseDate: '09/09/20',
            genre: CLASSICAL,
            artist: artists,
            recordCompany: recordcompanies,
            songs: ['purple','green','yellow']
        },
        {
            _id: uuid.v4(),
            title: 'one',
            releaseDate: '09/23/20',
            genre: rock,
            artist: artists,
            recordCompany: recordcompanies,
            songs: ['two','three','four']
        }
        ]);
        await recordCompaniesCollection.insertMany([
        {
        _id: uuid.v4(),
        name: "winter",
        foundedYear: 2017,
        country: 'Korea',
        albums: ['summer', 'one', 'purple'],
        numOfAlbums: 3
        },
        {
            _id: uuid.v4(),
            name: "boop",
            foundedYear: 2017,
            country: 'China',
            albums: ['three', 'yellow', 'four'],
            numOfAlbums: 3
        }
        ]);
        console.log('Done seeding database');
        await closeConnection();
      }; 
      main().catch(console.log);
    