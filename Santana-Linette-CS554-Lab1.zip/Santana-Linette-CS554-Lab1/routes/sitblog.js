
import express from 'express';
import bcrypt from 'bcrypt';
import { checkUserLoggedIn, checkUserIsAuthor } from '../middleware/auth.js';
import { registerUser, loginUser } from '../data/users.js';
import * as blogdata from '../data/blogPosts.js';
import * as commentdata from '../data/comments.js';
import * as userData from '../data/users.js';
import { users } from '../config/mongoCollection.js';
const router = express.Router();

router.get('/', async (req, res) => {
    let skip = req.query.skip ? parseInt(req.query.skip) : 0;
    let limit = req.query.limit ? parseInt(req.query.limit) : 20;
    if (limit > 100) {
        return res.status(400).json({ error: 'Limit value cannot be more than 100' });
    }

    try {
        const blogPosts = await blogdata.getPosts(skip, limit);
        res.json(blogPosts);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }
});

router.get('/:id',async (req, res) => {
    try {
        const blogPost = await blogdata.getPostById(req.params.id);
        res.json(blogPost);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }
});

router.post('/', checkUserLoggedIn, async (req, res) => {
    const { blogTitle, blogBody } = req.body;
    if (!blogTitle || !blogBody) {
        return res.status(400).json({ error: 'Blog title and body are required' });
    }
    try {
        const newPost = await blogdata.createPost(blogTitle, blogBody, req.session.user._id);
        res.status(201).json(newPost);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }

});

router.put('/:id', checkUserLoggedIn, checkUserIsAuthor,async (req, res) => {
    const { blogTitle, blogBody } = req.body;
    if (!blogTitle || !blogBody) {
        return res.status(400).json({ error: 'Blog title and body are required' });
    }
    try {
        const updatedPost = await blogdata.updatePost(req.params.id, blogTitle, blogBody);
        res.json(updatedPost);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }

});

router.patch('/:id', checkUserLoggedIn, checkUserIsAuthor,async (req, res) => {
    const { blogTitle, blogBody } = req.body;
    if (!blogTitle && !blogBody) {
        return res.status(400).json({ error: 'At least one of blog title or body must be provided' });
    }
    try {
        const updatedPost = await blogdata.updatePost(req.params.id, blogTitle, blogBody);
        res.json(updatedPost);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }
});

router.post('/:id/comments', checkUserLoggedIn, async (req, res) => {
    const { comment } = req.body;
    if (!comment) {
        return res.status(400).json({ error: 'Comment is required' });
    }
    try {
        const newComment = await commentdata.createComment(req.params.id, comment, req.session.user._id);

        res.status(201).json(newComment);
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }
});

router.delete('/:blogId/:commentId', checkUserLoggedIn, async (req, res) => {
    const { blogId, commentId } = req.params;
    const userId = req.session.user._id;
    try {
        const post = await blogdata.findOne({ _id: ObjectId(blogId) });
        const comment = post.commentdata.find(c => c._id.toString() === commentId);
        if (!comment) {
            return res.status(404).json({ error: 'Comment not found' });
        }
        if (comment.authorId.toString() !== userId) {
            return res.status(403).json({ error: 'Not authorized to delete this comment' });
        }
        await commentdata.updateOne(
            { _id: ObjectId(blogId) },
            { $pull: { comments: { _id: ObjectId(commentId) } } }
        );
        res.status(200).json({ message: 'Comment deleted' });
    } catch (e) {
        res.status(500).json({ error: e.toString() });
    }
});
router.post('/register', async (req, res) => {
    const { name, username, password } = req.body;
    try {
        const newUser = await registerUser(name, username,password);
        res.status(201).json(newUser);
    } catch (err) {
        console.error(err);
        res.status(400).json({ message: 'An error occurred', error: err.toString() });
    }
});
router.post('/signin', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'You must provide all fields' });
    }
    try {
        const user = await userData.loginUser(username, password);
        delete user.password;
        req.session.user = { _id: user._id, username: user.username };
        res.status(200).json(req.session.user);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ message: 'Could not log out, please try again.' });
        }
        res.clearCookie('sid');
        return res.status(200).json({ message: 'Logged out successfully.' });
    });
});
export default router;