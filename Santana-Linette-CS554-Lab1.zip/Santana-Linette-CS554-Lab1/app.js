import express from 'express';
import session from 'express-session';
import sitblogRoutes from './routes/sitblog.js';

const app = express();
app.use(express.json());
app.use(session({ secret: 'thisisasecret', resave: false, saveUninitialized: false , cookie: {secure:false}}));

app.use('/sitblog', sitblogRoutes);

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000/sitblog');
});