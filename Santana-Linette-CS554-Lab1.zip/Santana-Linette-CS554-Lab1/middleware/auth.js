import { posts } from '../config/mongoCollection.js';
export async function checkUserLoggedIn(req, res, next) {
    if (req.session && req.session.username) {
        next(); 
    } else {
        res.status(401).json({ error: 'User not logged in' }); 
    }
}

export async function checkUserIsAuthor(req, res, next) {
    const postCollection = await posts();
    const post = await postCollection.findOne({ _id: req.params.id });

    if (req.session.user._id.toString() === post.username._id.toString()) {
        next(); 
    } else {
        res.status(403).json({ error: 'User not authorized' }); 
    }
}