import { posts } from '../config/mongoCollection.js';
import { ObjectId } from 'mongodb';

export async function createComment(content, authorId, authorUsername,postId) {
    const postCollection = await posts();
    const commentCollection = await comment();
    if (!content || !authorId || !postId) {
        throw 'You must provide all fields';
    }
    const newComment = {
        _id: new ObjectId(),   
        "userThatPostedComment": {_id: authorId, username: authorUsername}, 
        "comment": content 
    };
    const updateInfo = await postCollection.updateOne(
        { _id: ObjectId(postId) },
        { $push: { comments: newComment } }
    );
    if (!updateInfo.matchedCount && !updateInfo.modifiedCount) throw 'Could not add comment to post';
    return newComment;
}
export async function deleteComment(blogId, commentId, userId) {
    const postCollection = await posts();
    const post = await postCollection.findOne({ _id: ObjectId(blogId) });
    if (!post) {
        throw 'Post not found';
    }
    const comment = post.comments.find(c => c._id.toString() === commentId);
    if (!comment) {
        throw 'Comment not found';
    }
    if (comment.authorId.toString() !== userId) {
        throw 'Not authorized to delete this comment';
    }
    await postCollection.updateOne(
        { _id: ObjectId(blogId) },
        { $pull: { comments: { _id: ObjectId(commentId) } } }
    );
    return { message: 'Comment deleted' };
}
