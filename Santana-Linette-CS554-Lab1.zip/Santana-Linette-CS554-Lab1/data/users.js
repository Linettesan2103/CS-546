import { users } from '../config/mongoCollection.js';
import bcrypt from 'bcryptjs';
import { ObjectId } from 'mongodb';
export async function registerUser(name, username, password) {
    username = username.trim();
    password = password.trim();
    name = name.trim();
    if (!username || !password || !name) {
       throw 'You must provide all fields';
    }
    const userCollection = await users();
    const userCheck = await userCollection.findOne({ username });
    if (userCheck) {
        throw 'Username already exists';
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      _id: new ObjectId(),
      name: name,
      username: username,
      password: hashedPassword
  };
    const insertInfo = await userCollection.insertOne(newUser);
    if (insertInfo.insertedCount === 0) {
        throw 'Could not register user';
    }
    const newId = insertInfo.insertedId;
    const user = await userCollection.findOne({ _id: newId });
    delete user.password;
    return user;
}
export async function loginUser(username, password) {
  if (!username || !password) {
      throw 'You must provide all fields';
  }
  const userCollection = await users();
  const user = await userCollection.findOne({ username });
  if (!user) {
      throw 'Invalid credentials';
  }
  const passwordMatches = await bcrypt.compare(password, user.password);
  if (!passwordMatches) {
      throw 'Invalid credentials';
  }
  delete user.password;
  return user;
}
