import { ObjectId } from 'mongodb';
import {posts } from '../config/mongoCollection.js';
export async function getPosts(skip, limit) {

    const postCollection = await posts();
    const blogposts = await postCollection.find().skip(skip).limit(limit).toArray();
    //console.log("getPosts", blogposts);
    return blogposts;
}
export async function getPostById(id) {
    const postCollection = await post();
    const post = await postCollection.findOne({ _id: id });
    if (!post) throw 'Post not found';
    return post;
}
export async function createPost(blogTitle, blogBody, userId, name) {
    const postCollection = await posts();
    if (!blogTitle || !blogBody || !userId || !name) throw 'You must provide all fields';
    const newPost = {
        _id: new ObjectId(),
        "blogTitle": blogTitle, 
        "blogBody": blogBody, 
        "userThatPosted": {_id: userId, username: name}, 
        "comments": []
    };
    const insertInfo = await postCollection.insertOne(newPost);
    if (insertInfo.insertedCount === 0) throw 'Could not add post';
    return newPost;
}
export async function updatePost(id, blogTitle, blogBody) {
    const postCollection = await posts();
    const updatedPost = {};
    if (blogTitle) updatedPost.blogTitle = blogTitle;
    if (blogBody) updatedPost.blogBody = blogBody;
    const updateInfo = await postCollection.updateOne({ _id: id }, { $set: updatedPost });
    if (updateInfo.modifiedCount === 0) throw 'Could not update post';
    return await postCollection.findOne({ _id: id });
}