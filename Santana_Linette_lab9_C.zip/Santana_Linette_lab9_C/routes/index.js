//Here you will require route files and export them as used in previous labs.
import express from 'express';
import path from 'path';
import { UrlToPath } from 'url';
import { dirname } from 'path';
const __filename = UrlToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();

router.get('/', function(req, res) {
    res.sendFile(path.join(__dirname, '../static', 'homepage.html'));
});
export default router;