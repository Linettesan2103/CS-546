//Here is where you will do all of the logic and processing for the palindrome and prime checking.
const isPalindrome = (str) => {
    const len = str.length;
    for (let i = 0; i < len / 2; i++) {
        if (str[i] !== str[len - 1 - i]) {
            return false;
        }
    }
    return true;
}
function isPrime(num) { 
    for(let i = 2, sqrt = Math.sqrt(num); i <= sqrt; i++) if(num % i === 0) 
    return false; 
    return num > 1; 
}

document.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    const input = document.querySelector('#palindrome_input').value.trim();

    if (!input) {
        const errorElement = document.createElement('p');
        errorElement.textContent = 'Error: Input cannot be empty or spaces only.';
        errorElement.className = 'error';
        document.body.appendChild(errorElement);
        return;
    }

    const words = input.toLowerCase().split(',').map(word => word.replace(/[^a-z0-9]/g, ''));
    const results = words.map(word => isPalindrome(word));
    const palindromeCount = results.filter(result => result).length;
    const listItem = document.createElement('li');
    listItem.textContent = `${JSON.stringify(results)}`;
    listItem.className = isPrime(palindromeCount) ? 'prime' : 'not-prime';
    listItem.style.color = isPrime(palindromeCount) ? '#00ff00' : '#ff0000';
    document.querySelector('#palindromes').appendChild(listItem);
});
