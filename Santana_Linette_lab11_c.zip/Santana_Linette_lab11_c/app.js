// Code server here
// Your server this week should not do any of the processing or calculations
// Your server only exists to allow someone to get to the HTML Page and download the associated assets to run the application
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import apiRoutes from './routes/routesApi.js';
import indexRoutes from './routes/index.js'; // import your index routes

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.use('/', indexRoutes); 
app.use('/api', apiRoutes); 
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});