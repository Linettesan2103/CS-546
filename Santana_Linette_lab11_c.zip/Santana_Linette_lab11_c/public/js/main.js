/* 
All of the functionality will be done in this client-side JS file.  
You will make client - side AJAX requests to the API and use jQuery to target and create elements on the page.
*/
$(document).ready(function() {
    $.ajax({
        url: 'http://api.tvmaze.com/shows',
        method: 'GET',
        success: function(shows) {
            createShowListItems(shows);
        }
    });
    $('#searchShows').on('submit', function(event) {
        event.preventDefault();

        const searchTerm = $('#show_search_term').val().trim();
        if (!searchTerm) {
            alert('Please enter a valid search.');
            return;
        }
        $.ajax({
            url: 'http://api.tvmaze.com/search/shows?q=' + searchTerm,
            method: 'GET',
            success: function(results) {
                const shows = results.map(function(result) {
                    return result.show;
                });
                createShowListItems(shows);
            }
        });
    });
    $('#tvShowList').on('click', 'a', function(event) {
        event.preventDefault();

        const showUrl = $(this).attr('href');
        $.ajax({
            url: showUrl,
            method: 'GET',
            success: function(show) {
                //createShowDetails(show);
            }
        });
    });
});

function createShowListItems(shows) {
    const tvShowList = document.getElementById('tvShowList');
    tvShowList.innerHTML = ''; 
    shows.forEach(function(show) {
    if (show && show.name) {
        const li = document.createElement('li');
        li.textContent = show.name;

        if (show._links && show._links.self && show._links.self.href) {
            li.innerHTML = `<a href="${show._links.self.href}">${show.name}</a>`;
            li.addEventListener('click', function(event) {
                event.preventDefault();
                displayShowDetails(show._links.self.href);
            });
        } else {
            li.innerHTML = `<a href="#">${show.name}</a>`;
        }

        tvShowList.appendChild(li);
    } 
    });

    $('#tvShowList').show();
    $('#showDetails').hide();
    $('#rootLink').hide();
}
function displayShowDetails(url) {
$('#tvShowList').hide();
$('#showDetails').empty().show();
$('#rootLink').show();
$.ajax({
    url: url,
    method: 'GET',
    success: function(show) {
        const showDetails = $('#showDetails');
        showDetails.empty();
        $('<h1></h1>').text(show.name || 'N/A').appendTo(showDetails);

        const imageSrc = show.image ? show.image.medium : '/css/no_image.jpeg';
        $('<img>').attr('src', imageSrc).appendTo(showDetails);

        const definitionList = $('<dl></dl>');
        $('<dt></dt>').text('Language').appendTo(definitionList);
        $('<dd></dd>').text(show.language || 'N/A').appendTo(definitionList);

        $('<dt></dt>').text('Genres').appendTo(definitionList);
        const genresList = $('<ul></ul>');
        if (show.genres && show.genres.length > 0) {
            show.genres.forEach(function(genre) {
                $('<li></li>').text(genre).appendTo(genresList);
            });
        } else {
            $('<li></li>').text('N/A').appendTo(genresList);
        }
        genresList.appendTo(definitionList);

        $('<dt></dt>').text('Average Rating').appendTo(definitionList);
        $('<dd></dd>').text(show.rating && show.rating.average ? show.rating.average : 'N/A').appendTo(definitionList);

        $('<dt></dt>').text('Network').appendTo(definitionList);
        $('<dd></dd>').text(show.network && show.network.name ? show.network.name : 'N/A').appendTo(definitionList);

        $('<dt></dt>').text('Summary').appendTo(definitionList);
        $('<dd></dd>').html(show.summary || 'N/A').appendTo(definitionList);

        definitionList.appendTo(showDetails);
    },
    error: function() {
        $('#showDetails').text('Error loading show details.');
    }
});
}
    $('#searchShows').submit(function(event) {
        event.preventDefault();
        const searchTerm = $('#show_search_term').val().trim();
    
        if (searchTerm === '') {
            $('#alertText').text('Please enter a valid search.');
            $('#alertMessage').show();
            return;
        }
    
        $('#tvShowList').empty();
        $('#showDetails').hide();
        $.ajax({
            url: `http://api.tvmaze.com/search/shows?q=${encodeURIComponent(searchTerm)}`,
            method: 'GET',
            success: function(data) {
                const shows = data.map(function(item) {
                    return item.show;
                });
                if (shows.length === 0) {
                    $('#alertText').text('No shows found for your search.');
                    $('#alertMessage').show();
                } else {
                    createShowListItems(shows);
                }
            },
            error: function() {
                $('#alertText').text('Error getting shows.');
                $('#alertMessage').show();
            }
        });
    });
    $.ajax({
        url: 'http://api.tvmaze.com/shows',
        method: 'GET',
        success: function(data) {
            const shows = data.map(function(item) {
                return item.show;
            });
            createShowListItems(shows);
        },
        error: function() {
            alert('Error getting shows.');
        }
    });
