//import express and express router as shown in lecture code and worked in previous labs.  Import your data functions from /data/characters.js that you will call in your routes below
import {Router} from 'express';
const router = Router();
import { searchCharacterByName, searchCharacterById } from '../data/characters.js'
router.route('/').get(async (req, res) => {
  try {
  res.render('home.handlebars');
} catch (error) {
  console.error(error);
  res.status(500).send('Internal server error');
}
});
router.route('/searchmarvelcharacters').post(async (req, res) => {
  const { searchCharacterByName: characterName } = req.body;
  try {
    const { searchCharacterByName: characterName } = req.body;
    if (!characterName) {
      return res.status(400).json({ error: 'Search term is required' });
    }
    const characters = await searchCharacterByName(characterName);
    if (characters.length === 0) {
      return res.status(404).json({ message: 'No characters found' });
    }
    res.render('characterSearchResults.handlebars', { characters });
  } catch (error) {
    console.error('Error searching characters:', error);
    res.status(500).send('Internal server error');
  }
});
router.route('/marvelcharacter/:id').get(async (req, res) => {
  const { id } = req.params;
  try {
    const character = await searchCharacterById(id);
    if (!character) {
      return res.status(404).render('error', { message: 'Character not found' });
    }
    res.render('characterDetails', { character });
  } catch (error) {
    console.error('Error retrieving character:', error);
    res.status(500).render('error', { message: 'Internal server error' });
  }
});
//export router
export default router;