//Here you will import route files and export them as used in previous labs
import express from 'express';
import character from './characters.js';
const app = express();
app.use(express.static('public'));
app.use('/', character);
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
export default app;