//import axios, md5
import axios from 'axios'
import md5 from 'blueimp-md5' //you will need to install this module;
const publickey = '05bd00df56875e7b5616fb17f0c749e9';
const privatekey = '27373620865f81144fbfe1a61d737d175fb53eab';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = 'https://gateway.marvel.com:443/v1/public/characters';
const url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
export const searchCharacterByName = async (name) => {
  //Function to search the api and return up to 15 characters matching the name param
  const url = `${baseUrl}?ts=${ts}&apikey=${publickey}&hash=${hash}&nameStartsWith=${name}&limit=15`;
  try {
    const response = await axios.get(url);
    return response.data.data.results;
  } catch (error) {
    console.error('Error searching character by name:', error);
    throw error;
  }
};

export const searchCharacterById = async (id) => {
  //Function to fetch a character from the api matching the id
  const url = `${baseUrl}/${id}?ts=${ts}&apikey=${publickey}&hash=${hash}`;
  try {
    const response = await axios.get(url);
    return response.data.data.results[0];
  } catch (error) {
    console.error('Error retrieving character:', error);
    throw error;
  }
};

