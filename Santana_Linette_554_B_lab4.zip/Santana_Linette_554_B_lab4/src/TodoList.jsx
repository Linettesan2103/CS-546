import Todo from './Todo.jsx';
import { useState } from 'react';

function TodoList({ todos, deleteTodo, toggleCompleted }) {
  return (
    <div>
      {todos.map(todo => (
        !todo.completed && (
          <div key={todo.id}>
            <h1>{todo.title}</h1>
            <p>{todo.description}</p>
            <p>Due Date: {todo.due}</p>
            <p>Completed: {todo.completed ? 'Yes' : 'No'}</p>
            <button onClick={() => deleteTodo(todo.id)}>Delete {todo.title}</button>
            <button onClick={() => toggleCompleted(todo.id)}>Complete {todo.title}</button>
          </div>
        )
      ))}
    </div>
  );
}
export default TodoList;