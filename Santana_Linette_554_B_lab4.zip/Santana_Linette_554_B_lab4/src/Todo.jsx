function Todo({ todo, deleteTodo, toggleCompleted }) {
  const buttonClick = () => {
    alert(todo.title + ' has been completed!');
    deleteTodo(todo.id)
  };

  const handleDeleteClick = () => {
    deleteTodo && deleteTodo(todo.id);
  };

  const isPastDue = new Date(todo.due) < new Date();

  return (
    <div>
      <h1 className={isPastDue ? 'past-due' : ''}>{todo.title}</h1>
      <p>{todo.description}</p>
      <p className={isPastDue ? 'past-due' : ''}>Due Date: {todo.due}</p>
      <p>Completed: {todo.completed ? 'Yes' : 'No'}</p>
      {deleteTodo && <button onClick={handleDeleteClick}>Delete</button>}
      <button onClick={buttonClick}> Complete {todo.title} Now!
        {todo.completed ? 'Mark Incomplete' : 'Complete'}
      </button>
    </div>
  );
}

export default Todo;