import { useState} from 'react';
import TodoList from './TodoList.jsx';
import CompletedTodos from './CompletedTodos.jsx';
import AddTodo from './addTodo.jsx';
function App(props) {
  const [count, setCount]=useState([
    {
        id: 1,
        title: 'Pay cable bill',
        description: 'Pay the cable bill by the 15th of the month',
        due: '3/15/2023',
        completed: false
    },
    {
        id: 2,
        title: 'finish homework',
        description: 'homework is due on the at 11:59 of the 29th',
        due: '3/29/2023',
        completed: false
    },
    {
        id: 3,
        title: 'meet with ryan',
        description: 'meet with ryan to talk about resume',
        due: '2/27/2023',
        completed: false
    },
    {
        id: 4,
        title: 'buy new I phone 15',
        description: 'Go to the apple store to buy new iphone',
        due: '3/21/2023',
        completed: false

    },
    {
        id: 5,
        title: 'buy maria a present',
        description: 'remember to buy maria a toy for her birthday',
        due: '3/24/2023',
        completed: false
    },
    {
        id: 6,
        title: 'take the trash out',
        description: 'take the trash out before the truck comes to pick up the trash',
        due: '2/29/2023',
        completed: false
    },
    {
      id: 7,
        title: 'complete homework 3',
        description: 'Complete homework 3 for cs 392',
        due: '3/27/2023',
        completed: false
    },
    {
      id: 8,
        title: 'take benny to the vet',
        description: 'take benny to the veterinary for his vaccines',
        due: '3/3/2023',
        completed: false
    },
    {
      id: 9,
        title: 'change tires',
        description: 'remember to change tires of the car',
        due: '3/10/2023',
        completed: false
    },
    {
      id: 10,
        title: 'Do nails',
        description: 'Do nails before my birthday',
        due: '3/20/2023',
        completed: false
    }
  ]);
  function deleteTodo(id) {
    const newTodos = [];
    for (let i = 0; i < count.length; i++) {
      if (count[i].id !== id) {
        newTodos.push(count[i]);
      }
    }
    setCount(newTodos);
  }
  function toggleCompleted(id) {
    const newTodos = [];
    for (let i = 0; i < count.length; i++) {
      if (count[i].id === id) {
        newTodos.push({ ...count[i], completed: !count[i].completed });
      } else {
        newTodos.push(count[i]);
      }
    }
    setCount(newTodos);
  }
  const addTodo = (todo) => {
    setCount(prevTodos => [
      ...prevTodos,
      { id: prevTodos.length + 1, completed: false, ...todo }
    ]);
  };
  const incompleteTodos = count.filter(todo => !todo.completed);
  const completedTodos = count.filter(todo => todo.completed);

  return(
    <div>
      <AddTodo addTodo={addTodo}/>
      <TodoList 
        todos={incompleteTodos} 
        deleteTodo={deleteTodo} 
        toggleCompleted={toggleCompleted} 
      />
      <CompletedTodos 
        todos={completedTodos} 
        toggleCompleted={toggleCompleted} 
      />
    </div>
  )
}
export default App;

