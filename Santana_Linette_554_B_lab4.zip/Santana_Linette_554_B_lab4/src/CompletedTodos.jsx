import Todo from './Todo.jsx';
import { useState } from 'react';
function CompletedTodos({ todos, toggleCompleted }) {
  return (
    <div>
      {todos.map(todo => (
        todo.completed && (
          <div key={todo.id}>
            <h1>{todo.title}</h1>
            <p>{todo.description}</p>
            <p>Due Date: {todo.due}</p>
            <p>Completed: {todo.completed ? 'Yes' : 'No'}</p>
            <button onClick={() => toggleCompleted(todo.id)}>Mark {todo.title} Incomplete</button>
          </div>
        )
      ))}
    </div>
  );
}

export default CompletedTodos;