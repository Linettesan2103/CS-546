
import React from 'react';
import { useState } from 'react';

function AddTodo({ addTodo }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [due, setDue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (title.trim().length < 5 || description.trim().length < 25 || !due) {
      alert('Please fill out the form correctly.');
      return;
    }

    addTodo({
      title: title.trim(),
      description: description.trim(),
      due: new Date(due).toLocaleDateString('en-US'),
    });

    setTitle('');
    setDescription('');
    setDue('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Title:
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </label>
      <label>
        Description:
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
      </label>
      <label>
        Due:
        <input type="date" value={due} min={new Date().toISOString().split('T')[0]} onChange={(e) => setDue(e.target.value)} required />
      </label>
      <input type="submit" value="Add Todo" />
    </form>
  );
}

export default AddTodo;